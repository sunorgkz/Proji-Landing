/**
 * Proji Extension — Background Service Worker v2.1
 * Primary: Groq (llama-3.1-8b-instant) — ultra fast
 * Fallback: OpenRouter
 */

const GROQ_API = 'https://api.groq.com/openai/v1/chat/completions';
const OPENROUTER_API = 'https://openrouter.ai/api/v1/chat/completions';
const PROJI_API = 'https://app.proji.kz/api/v1/extension/capture';
const ANALYTICS_API = 'https://app.proji.kz/api/v1/extension/analytics';

// ─── DETERMINISTIC SAFETY/RELEVANCE FILTER ────────────────────────────────
// Не полагаемся только на то, что LLM послушается системного промпта —
// дополнительно фильтруем по ключевым словам на стороне кода.
// Покрывает: политика/госвласть, военные темы, и новости о СТОРОННИХ
// компаниях/сделках, которые пользователь не может "завести как проект".

const BLOCKED_PATTERNS = [
  /президент/i, /токаев/i, /парламент/i, /курултай/i, /депутат/i, /министр/i,
  /правительств/i, /реформ/i, /суверенитет/i, /независимост/i, /выбор[ыа]/i,
  /война/i, /военн/i, /санкци/i, /катастроф/i, /терак/i, /погиб/i, /убий/i,
  /смерт/i, /криминал/i, /преступлен/i,
  /\bдоля\b.{0,25}\bв\b/i, /поглощени/i, /слияни/i, /акционер/i, /сделк[аиу]/i,
  /\bm&a\b/i, /приватизац/i, /национализац/i,
];

function isBlockedContent(data) {
  const text = `${data?.cta || ''} ${data?.title || ''} ${data?.description || ''}`;
  return BLOCKED_PATTERNS.some(rx => rx.test(text));
}

const GENERIC_FALLBACKS = [
  { action: 'knowledge', cta: 'Сохрани важное', title: 'Все знания команды в одном месте', description: 'Proji Studio помогает не терять ценную информацию', items: [] },
  { action: 'task', cta: 'Не упусти задачу', title: 'Фиксируй идеи сразу — не забудешь', description: 'Добавляй задачи в Proji прямо сейчас, пока не забыл', items: [] },
  { action: 'project', cta: 'Организуй работу', title: 'Структурируй проекты своей команды', description: 'Proji помогает довести начатое до результата', items: [] },
];

function pickGenericFallback() {
  return GENERIC_FALLBACKS[Math.floor(Math.random() * GENERIC_FALLBACKS.length)];
}

const DEFAULTS = {
  groqKey: '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',
  groqModel: 'llama-3.1-8b-instant',
};

// ─── INSTALL: save defaults ───────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['groqKey'], (r) => {
    if (!r.groqKey) {
      chrome.storage.sync.set({ groqKey: DEFAULTS.groqKey, groqModel: DEFAULTS.groqModel });
    }
  });

  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'proji-analyze', title: '🔍 Проанализировать через Proji AI', contexts: ['selection', 'page'] });
    chrome.contextMenus.create({ id: 'proji-task', title: '✓ Добавить как задачу в Proji', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'proji-knowledge', title: '📚 Сохранить в базу знаний Proji', contexts: ['selection'] });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'proji-analyze') {
    chrome.tabs.sendMessage(tab.id, { type: 'CONTEXT_MENU_ANALYZE' });
    return;
  }
  const action = info.menuItemId === 'proji-knowledge' ? 'knowledge' : 'task';
  const params = new URLSearchParams({ source: 'extension_contextmenu', action, title: (info.selectionText || '').slice(0, 80), url: tab?.url || '' });
  chrome.tabs.create({ url: `https://app.proji.kz/quick-add?${params}` });
});

// ─── MESSAGE HANDLER ─────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PROJI_ANALYZE') {
    handleAnalyze(message.payload)
      .then(result => sendResponse({ result }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }
  if (message.type === 'PROJI_CAPTURE') {
    handleCapture(message.payload).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === 'PROJI_DISCUSS') {
    handleDiscuss(message.payload)
      .then(reply => sendResponse({ reply }))
      .catch(err => sendResponse({ reply: 'Ошибка: ' + err.message }));
    return true;
  }
  if (message.type === 'PROJI_TRACK') {
    handleTrack(message.payload).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === 'GET_EVENTS') {
    chrome.storage.local.get(['pbEvents'], r => sendResponse({ events: r.pbEvents || [] }));
    return true;
  }
  if (message.type === 'CLEAR_EVENTS') {
    chrome.storage.local.set({ pbEvents: [] }, () => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === 'GET_SETTINGS') {
    chrome.storage.sync.get(['groqKey','groqModel','openrouterKey','openrouterModel','projiApiUrl','projiToken','enabled'], r => sendResponse(r));
    return true;
  }
});

// ─── ANALYZE: Groq first, OpenRouter fallback ─────────────────────────────

async function handleAnalyze(ctx) {
  const settings = await getSettings();

const systemPrompt = `Ты — встроенный ассистент Proji, системы проектного управления и продуктивности (проекты, задачи, база знаний, автоматизация процессов).

ТВОЯ ЗАДАЧА: прочитать контент страницы (статья, поисковая выдача, AI-диалог, рекламный блок) и предложить КОНКРЕТНОЕ действие в Proji, которое тематически связано именно с этим контентом — не обобщённое.

Логика по типам:
• type=page / news_page — прочитай суть статьи/страницы. Если в ней есть процесс, проект, задача, дедлайн, идея, цифры, решение — предложи перенести именно ЭТО в Proji (например: «Сравниваешь поставщиков? Заведи проект сравнения в Proji», «Эта методика — сохрани в базу знаний команды»). cta и title должны отражать тему страницы, а не быть общими.
• type=search_query — посмотри на сам запрос и сниппеты результатов. Если человек что-то изучает, планирует, выбирает, сравнивает — предложи оформить это как задачу/проект/исследование в Proji по теме поиска.
• type=ai_chat — посмотри, что обсуждается с AI. Если в диалоге есть план, список шагов, идея, код, решение — предложи зафиксировать именно это (задача/проект/база знаний) с привязкой к сути диалога.
• type=selection — пользователь выделил текст: предложи действие по смыслу выделенного.

Всегда формулируй через призму Proji: проекты, задачи, база знаний, автоматизация процессов, командная работа — НЕ просто "сохрани страницу", а что именно из неё стоит превратить в проект/задачу/знание.

МАСШТАБ И РЕАЛИСТИЧНОСТЬ (обязательно):
Предлагай только то, что реально может сделать ОДИН человек или небольшая команда в Proji. ЗАПРЕЩЕНО предлагать буквально "организовать"/"создать"/"провести" тему государственного, глобального или вне-личного масштаба (Чемпионат мира, выборы, война, реформа, запуск ракеты, открытие завода и т.п.) — обычный пользователь это не организует. В таких случаях переформулируй на то, что человек МОЖЕТ сделать в связи с темой:
- использовать как референс/контекст в своей работе ("Используй это как референс для своего проекта"),
- изучить и законспектировать в базу знаний ("Законспектируй ключевые тезисы"),
- спланировать СВОЁ небольшое мероприятие/задачу по аналогии, а не саму тему ("Планируешь похожее мероприятие? Заведи проект"),
- поставить себе задачу-напоминание следить за темой.
Если сомневаешься, реалистично ли действие для одного пользователя — выбирай более скромную, выполнимую формулировку.

БАЗА ЗНАНИЙ ДЛЯ НАВЫКОВ/ФРЕЙМВОРКОВ (обязательно):
Если контент — это полезный навык, бизнес-фреймворк, методика, инструкция, чек-лист или обучающий материал (не новость, не общая статья) — cta должен быть ИМЕННО "Забрать в базу знаний", action="knowledge".

БЕЗОПАСНОСТЬ КОНТЕНТА (обязательно, приоритет выше всего остального):
Если тема — политика, религия, войны/конфликты, катастрофы, болезни/смерть, криминал, NSFW, спорные общественные вопросы — НЕ анализируй и не упоминай тему. Верни один из универсальных вариантов (выбери случайно):
• {"action":"knowledge","cta":"Сохрани важное","title":"Все знания команды в одном месте","description":"Proji Studio помогает не терять ценную информацию","items":[]}
• {"action":"task","cta":"Не упусти задачу","title":"Фиксируй идеи сразу — не забудешь","description":"Добавляй задачи в Proji прямо сейчас, пока не забыл","items":[]}
• {"action":"project","cta":"Организуй работу","title":"Структурируй проекты своей команды","description":"Proji помогает довести начатое до результата","items":[]}

Ответь ТОЛЬКО JSON без markdown:
{
  "action": "task|project|knowledge|idea|meeting|decision",
  "cta": "Призыв к действию — глагол + конкретная суть темы (макс 35 символов, русский)",
  "title": "Конкретный заголовок, отражающий тему страницы (макс 60 символов, русский)",
  "description": "Почему именно это стоит перенести в Proji (макс 90 символов, русский)",
  "items": [{"type":"task|knowledge","title":"Подпункт"}]
}

Примеры (тематически привязанные): "Заведи проект ремонта", "Сравни поставщиков в Proji", "Сохрани методику в базу", "Распиши шаги задачами"`;

  const userMsg = `Platform: ${ctx.platform}\nType: ${ctx.type}\nURL: ${ctx.url || ''}\n\n${ctx.text}`;

  // 0. Жёсткий пред-фильтр по исходному тексту — если контент сам по себе
  // политический/госвласть/чужая корпоративная сделка, даже не тратим вызов LLM.
  if (isBlockedContent({ description: ctx.text })) {
    return pickGenericFallback();
  }

  let result = null;

  // 1. Пробуем Groq
  const groqKey = settings.groqKey || DEFAULTS.groqKey;
  if (groqKey) {
    try {
      result = await callLLM(GROQ_API, groqKey, settings.groqModel || DEFAULTS.groqModel, systemPrompt, userMsg, 6000);
    } catch (err) {
      console.warn('[Proji] Groq failed:', err.message, '— trying OpenRouter');
    }
  }

  // 2. Fallback: OpenRouter
  if (!result) {
    const orKey = settings.openrouterKey;
    if (orKey) {
      try {
        result = await callLLM(OPENROUTER_API, orKey, settings.openrouterModel || 'google/gemini-flash-1.5', systemPrompt, userMsg, 10000);
      } catch (err) {
        throw new Error('Groq и OpenRouter недоступны: ' + err.message);
      }
    }
  }

  if (!result) return null; // нет ключей

  // 3. Пост-фильтр — на случай если LLM всё же сгенерировал что-то по
  // запрещённой теме вопреки системному промпту (не доверяем ему слепо).
  if (isBlockedContent(result)) {
    return pickGenericFallback();
  }

  return result;
}

async function callLLM(endpoint, apiKey, model, systemPrompt, userContent, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  const isGroq = endpoint.includes('groq.com');

  const body = {
    model,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userContent },
    ],
    max_tokens: 350,
    temperature: 0.2,
    ...(isGroq ? {} : { response_format: { type: 'json_object' } }),
  };

  const response = await fetch(endpoint, {
    method: 'POST',
    signal: controller.signal,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      ...(isGroq ? {} : { 'HTTP-Referer': 'https://proji.kz', 'X-Title': 'Proji Extension' }),
    },
    body: JSON.stringify(body),
  });

  clearTimeout(timer);

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    if (response.status === 401) throw new Error('Неверный API ключ');
    if (response.status === 429) throw new Error('Лимит запросов');
    throw new Error(`HTTP ${response.status}`);
  }

  const data = await response.json();
  const raw = data.choices?.[0]?.message?.content || '{}';
  const clean = raw.replace(/```json|```/g, '').trim();

  // Groq иногда возвращает текст до JSON — вырезаем JSON блок
  const jsonMatch = clean.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error('Нет JSON в ответе');

  return JSON.parse(jsonMatch[0]);
}

// ─── DISCUSS ("Обсудить") ────────────────────────────────────────────────
// Свободный диалог с ассистентом Proji про текущую страницу/рекомендацию.
// В отличие от handleAnalyze, ответ — обычный текст, не JSON.

async function handleDiscuss(payload) {
  const settings = await getSettings();
  const { messages = [], ctx, analysis } = payload || {};

  const lastUserMsg = [...messages].reverse().find(m => m.role === 'user')?.content || '';
  if (isBlockedContent({ description: lastUserMsg })) {
    return 'Это лучше обсудить в другом месте 🙂 А вот по части организации работы в Proji — спрашивай, помогу.';
  }

  const discussPrompt = `Ты — дружелюбный ассистент Proji (система проектного управления и продуктивности: проекты, задачи, база знаний, автоматизация процессов).
Сейчас ты обсуждаешь с пользователем тему страницы, которую он смотрит, и конкретную рекомендацию Proji.

Контекст страницы: ${(ctx?.text || '').slice(0, 1200)}
Рекомендация Proji: "${analysis?.title || analysis?.cta || ''}" — ${analysis?.description || ''}

Правила:
- Отвечай кратко: 2-4 предложения, по-русски, дружелюбно, без воды.
- Помогай разложить тему на конкретные шаги/задачи/структуру проекта в Proji, если уместно.
- НЕ обсуждай политику, религию, войны, катастрофы, криминал, NSFW — вежливо уведи разговор к продуктивности.
- Не выдумывай функций Proji, которых не упоминал пользователь или контекст.
- ВАЖНО: пиши обычным текстом без markdown — никаких **, __, #, бэктиков, нумерованных/маркированных списков со звёздочками. Если нужен список — пиши через тире "- " или просто предложениями.`;

  const chatMessages = [
    { role: 'system', content: discussPrompt },
    ...messages.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 500) })),
  ];

  let reply = null;
  const groqKey = settings.groqKey || DEFAULTS.groqKey;
  if (groqKey) {
    try {
      reply = await callLLMChat(GROQ_API, groqKey, settings.groqModel || DEFAULTS.groqModel, chatMessages, 8000);
    } catch (err) {
      console.warn('[Proji] Discuss via Groq failed:', err.message);
    }
  }
  if (!reply && settings.openrouterKey) {
    try {
      reply = await callLLMChat(OPENROUTER_API, settings.openrouterKey, settings.openrouterModel || 'google/gemini-flash-1.5', chatMessages, 10000);
    } catch (err) {
      console.warn('[Proji] Discuss via OpenRouter failed:', err.message);
    }
  }

  if (!reply) return 'Сейчас не получается ответить — попробуй чуть позже.';
  if (isBlockedContent({ description: reply })) {
    return 'Это лучше обсудить в другом месте 🙂 А вот по части организации работы в Proji — спрашивай, помогу.';
  }
  return reply;
}

async function callLLMChat(endpoint, apiKey, model, messages, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const isGroq = endpoint.includes('groq.com');

  const response = await fetch(endpoint, {
    method: 'POST',
    signal: controller.signal,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      ...(isGroq ? {} : { 'HTTP-Referer': 'https://proji.kz', 'X-Title': 'Proji Extension' }),
    },
    body: JSON.stringify({ model, messages, max_tokens: 220, temperature: 0.4 }),
  });

  clearTimeout(timer);

  if (!response.ok) {
    if (response.status === 401) throw new Error('Неверный API ключ');
    if (response.status === 429) throw new Error('Лимит запросов');
    throw new Error(`HTTP ${response.status}`);
  }

  const data = await response.json();
  return (data.choices?.[0]?.message?.content || '').trim();
}

// ─── CAPTURE ─────────────────────────────────────────────────────────────

async function handleCapture(payload) {
  const settings = await getSettings();
  const apiUrl = settings.projiApiUrl || PROJI_API;
  const token = settings.projiToken || '';
  try {
    await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        'X-Source': 'proji-extension',
      },
      body: JSON.stringify(payload),
    });
  } catch (_) {}
}

function getSettings() {
  return new Promise(r => chrome.storage.sync.get(['groqKey','groqModel','openrouterKey','openrouterModel','projiApiUrl','projiToken','enabled'], r));
}

// ─── ANALYTICS ──────────────────────────────────────────────────────────────
// Событие: { event, action, cta, title, envType, platform, url, hostname, timestamp }
// event: impression | click | dismiss | feedback_up | feedback_down | pageview

const MAX_LOCAL_EVENTS = 1000;

async function handleTrack(payload) {
  const event = { ...payload, ts: payload.timestamp || new Date().toISOString() };

  // 1. Локальный лог в storage.local — для попапа/отладки/офлайн-аналитики
  await new Promise(resolve => {
    chrome.storage.local.get(['pbEvents'], r => {
      const events = r.pbEvents || [];
      events.push(event);
      if (events.length > MAX_LOCAL_EVENTS) events.splice(0, events.length - MAX_LOCAL_EVENTS);
      chrome.storage.local.set({ pbEvents: events }, resolve);
    });
  });

  // 2. Отправка на бэкенд Proji (если настроен) — для централизованной аналитики
  const settings = await getSettings();
  const apiUrl = settings.projiAnalyticsUrl || ANALYTICS_API;
  const token = settings.projiToken || '';
  try {
    await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        'X-Source': 'proji-extension',
      },
      body: JSON.stringify(event),
    });
  } catch (_) {}
}
