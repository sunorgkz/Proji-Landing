/**
 * Proji Extension v3.2
 * Static fallback-first: always shows "сделать в proji" link
 * LLM analysis runs silently in background; upgrades card if it succeeds
 */
(function () {
'use strict';

// ─── SKIP ON PROJI'S OWN DOMAINS (avoid self-duplication) ──────────────────

const PROJI_DOMAINS = ['proji.kz', 'app.proji.kz'];
if (PROJI_DOMAINS.some(d => location.hostname === d || location.hostname.endsWith('.' + d))) {
  return;
}

// ─── PLATFORM ─────────────────────────────────────────────────────────────

const AI_PLATFORMS = {
  'chatgpt.com':           '[data-message-author-role] .markdown, [data-message-author-role] p',
  'chat.openai.com':       '[data-message-author-role] .markdown',
  'gemini.google.com':     '.model-response-text, .response-container-content',
  'claude.ai':             '[data-testid="assistant-message"] .prose',
  'chat.deepseek.com':     '.ds-markdown, .message-content',
  'grok.com':              '.message-bubble',
  'copilot.microsoft.com': '.ac-textBlock',
};

const hostname = location.hostname;
const AI_SEL   = Object.entries(AI_PLATFORMS).find(([k]) => hostname.includes(k))?.[1] || null;
const PLATFORM = Object.keys(AI_PLATFORMS).find(k => hostname.includes(k)) || 'web';

// ─── DETECT ENV ───────────────────────────────────────────────────────────

function detectEnv() {
  const u = location.href;
  if (AI_SEL) return 'ai';
  if (
    (hostname.includes('google.')    && u.includes('/search')) ||
    (hostname.includes('yandex.')    && (u.includes('/search') || u.includes('yandsearch'))) ||
    (hostname.includes('bing.com')   && u.includes('/search')) ||
    hostname.includes('duckduckgo.com')
  ) return 'search';
  if (
    document.querySelector('[itemtype*="NewsArticle"],[typeof*="NewsArticle"]') ||
    document.querySelector('article') ||
    document.querySelector('.article-body,.news-body,.post-content,.article__body')
  ) return 'news';
  return 'web';
}
const ENV = detectEnv();

// ─── FONT ────────────────────────────────────────────────────────────────

if (!document.getElementById('proji-font')) {
  const l = document.createElement('link');
  l.id = 'proji-font'; l.rel = 'stylesheet';
  l.href = 'https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap';
  document.head.appendChild(l);
}

// ─── THEME ────────────────────────────────────────────────────────────────

function detectTheme() {
  const tryBg = sel => {
    const el = sel ? document.querySelector(sel) : null;
    if (!el) return null;
    const bg = getComputedStyle(el).backgroundColor;
    return (!bg || bg.includes('rgba(0, 0, 0, 0)') || bg === 'transparent') ? null : bg;
  };
  const raw = tryBg('main') || tryBg('[role="main"]') || tryBg('body') || 'rgb(15,15,26)';
  const rgb = raw.match(/[\d.]+/g)?.map(Number) || [15,15,26];
  const lum = (rgb[0]*299 + rgb[1]*587 + rgb[2]*114) / 1000;
  const isDark = lum < 140;
  const [r,g,b] = rgb;
  const siteInput = document.querySelector('textarea, button[class]');
  const siteR = siteInput ? Math.min(Math.max(parseInt(getComputedStyle(siteInput).borderRadius)||12, 10), 24) : 14;
  return {
    isDark,
    cardBg: isDark ? `rgb(${Math.min(r+18,255)},${Math.min(g+18,255)},${Math.min(b+22,255)})` : '#ffffff',
    border: isDark ? 'rgba(255,255,255,0.11)' : 'rgba(0,0,0,0.1)',
    text:   isDark ? '#f2f2ff' : '#111128',
    muted:  isDark ? 'rgba(242,242,255,0.42)' : 'rgba(11,11,40,0.42)',
    shadow: isDark ? '0 8px 28px rgba(0,0,0,0.45)' : '0 6px 22px rgba(0,0,0,0.12)',
    radius: siteR + 'px',
  };
}

// ─── CONTEXT ──────────────────────────────────────────────────────────────

function extractContext() {
  if (AI_SEL) {
    const nodes = [...document.querySelectorAll(AI_SEL)]
      .map(n => n.innerText?.trim()).filter(t => t && t.length > 10).slice(-8);
    if (nodes.length) return { type:'ai_chat', platform:PLATFORM, text:nodes.join('\n\n').slice(0,2500), url:location.href };
  }
  const sel = window.getSelection()?.toString()?.trim();
  if (sel?.length > 30) return { type:'selection', platform:PLATFORM, text:sel.slice(0,2000), url:location.href };
  const main = document.querySelector('main,article,[role="main"]') || document.body;
  return { type:'page', platform:PLATFORM, text:main.innerText?.replace(/\s{3,}/g,'\n\n')?.trim()?.slice(0,1800)||'', url:location.href, pageTitle:document.title };
}

// ─── LLM (hard 8s timeout, always resolves) ──────────────────────────────

function callLLM(payload) {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(null), 8000); // hard timeout → null
    try {
      chrome.runtime.sendMessage({ type:'PROJI_ANALYZE', payload }, res => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return resolve(null);
        resolve(res?.result || null);
      });
    } catch (_) {
      clearTimeout(timer);
      resolve(null);
    }
  });
}

// ─── OPEN PROJI ───────────────────────────────────────────────────────────
// chat (опционально) — переписка из "Обсудить", передаётся в Proji вместе
// с темой/заголовком/ссылкой, чтобы там сразу был весь контекст.

function openProji(action, analysis, ctx, chat) {
  const p = new URLSearchParams({
    source:'extension', platform:PLATFORM, action,
    title:(analysis?.title||analysis?.cta||'').slice(0,100),
    description:(analysis?.description||'').slice(0,200),
    context:(ctx?.text||'').slice(0,500),
    url:ctx?.url||location.href,
  });
  if (chat && chat.length) {
    const transcript = chat.map(m => `${m.role === 'user' ? 'Я' : 'Proji'}: ${m.content}`).join('\n').slice(0, 2500);
    p.set('discussion', transcript);
  }
  window.open(`https://app.proji.kz/quick-add?${p}`, '_blank');
  try {
    chrome.runtime.sendMessage({
      type: 'PROJI_CAPTURE',
      payload: {
        action, title: analysis?.title, description: analysis?.description,
        platform: PLATFORM, url: ctx?.url || location.href,
        hasDiscussion: !!(chat && chat.length),
        timestamp: new Date().toISOString(),
      },
    });
  } catch(_) {}
}

function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// Ответы LLM иногда приходят с markdown (**, #, `) — в виджете рендерим
// как обычный текст, поэтому чистим разметку перед показом.
function cleanMarkdown(s) {
  return (s || '')
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/^#{1,6}\s*/gm, '')
    .replace(/`{1,3}([^`]*)`{1,3}/g, '$1')
    .trim();
}

// ─── ANALYTICS ──────────────────────────────────────────────────────────────
// event: impression | click | dismiss | feedback_up | feedback_down | pageview

function trackEvent(event, data) {
  try {
    chrome.runtime.sendMessage({
      type: 'PROJI_TRACK',
      payload: {
        event,
        action: data?.action || '',
        cta: data?.cta || '',
        title: data?.title || '',
        envType: ENV,
        platform: PLATFORM,
        url: location.href,
        hostname: location.hostname,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (_) {}
}

// ═══════════════════════════════════════════════════════════════════════════
//  FLOATING BUBBLE
// ═══════════════════════════════════════════════════════════════════════════

let BS = { el:null, analyzing:false, lastText:'', lastAnalysis:null, lastCtx:null, timer:null };

// ─── FEEDBACK ("Точно?") ─────────────────────────────────────────────────
// 👍 — фиксируем как успех, благодарим. 👎 — считаем рекомендацию неудачной
// и сразу подменяем заголовок/описание на безопасный общий вариант, чтобы
// человек не застревал на промахе мимо темы.

const GENERIC_ALTS = [
  { action: 'knowledge', cta: 'Сохрани важное', title: 'Сохрани важное', description: 'Proji Studio помогает не терять ценную информацию' },
  { action: 'task', cta: 'Не упусти задачу', title: 'Не упусти задачу', description: 'Добавляй задачи в Proji прямо сейчас, пока не забыл' },
  { action: 'project', cta: 'Организуй работу', title: 'Организуй работу', description: 'Proji помогает довести начатое до результата' },
];

function applyDislikeAlt() {
  const el = BS.el;
  if (!el) return;
  const currentCta = BS.lastAnalysis?.cta || BS.lastAnalysis?.title;
  let alt = GENERIC_ALTS[Math.floor(Math.random() * GENERIC_ALTS.length)];
  let tries = 0;
  while (alt.cta === currentCta && tries < 5) {
    alt = GENERIC_ALTS[Math.floor(Math.random() * GENERIC_ALTS.length)];
    tries++;
  }
  el.querySelector('#pb-l1').textContent = alt.cta;
  el.querySelector('#pb-l2').textContent = alt.description;
  BS.lastAnalysis = { ...alt };
}

function wireFeedback(el) {
  const fbUp = el.querySelector('#pb-fb-up');
  const fbDown = el.querySelector('#pb-fb-down');
  if (fbUp) fbUp.addEventListener('click', () => {
    trackEvent('feedback_up', BS.lastAnalysis);
    el.querySelector('#pb-fb').innerHTML = '<span class="pb-fb-label">Спасибо за отзыв!</span>';
  });
  if (fbDown) fbDown.addEventListener('click', () => {
    trackEvent('feedback_down', BS.lastAnalysis);
    applyDislikeAlt();
  });
}

function createBubble() {
  if (document.getElementById('proji-bubble')) return;

  const el = document.createElement('div');
  el.id = 'proji-bubble';

  // DEFAULT STATE: always visible static link — no spinner
  el.innerHTML = `
    <!-- Mini state: static fallback link + (conditionally) "reopen discussion" -->
    <div class="pb-mini" id="pb-mini">
      <a class="pb-static" id="pb-static" href="https://proji.kz" target="_blank">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <rect width="24" height="24" rx="6" fill="#4F6EF7"/>
          <path d="M7 8h6a3 3 0 010 6H7V8z" fill="white"/>
          <rect x="7" y="17" width="4" height="2" rx="1" fill="white"/>
        </svg>
        <span class="pb-s-thin">сделай в&hellip;</span>&nbsp;<span class="pb-s-bold">Proji</span>
      </a>
      <button class="pb-reopen" id="pb-reopen" style="display:none" title="Открыть обсуждение">↑</button>
    </div>

    <!-- Upgraded card: hidden until LLM analysis succeeds -->
    <div class="pb-card" id="pb-card" style="display:none">
      <button class="pb-collapse" id="pb-collapse" title="Свернуть">↓</button>
      <div class="pb-l1" id="pb-l1"></div>

      <!-- Описание + быстрая оценка точности — единый блок, вторая строка -->
      <div class="pb-meta" id="pb-meta">
        <div class="pb-l2" id="pb-l2"></div>
        <div class="pb-fb" id="pb-fb">
          <span class="pb-fb-label">Точно?</span>
          <button class="pb-fb-btn" id="pb-fb-up" title="Да, в точку">👍</button>
          <button class="pb-fb-btn" id="pb-fb-down" title="Мимо">👎</button>
        </div>
      </div>

      <div class="pb-actions" id="pb-actions">
        <button class="pb-discuss" id="pb-discuss" title="Обсудить с ассистентом Proji">
          💬&nbsp;Обсудить
        </button>
        <button class="pb-l3" id="pb-l3">
          <span class="pb-thin">сделать в</span>&nbsp;<span class="pb-bold">Proji</span>
          <span class="pb-arr">&nbsp;→</span>
        </button>
      </div>

      <!-- Inline chat: hidden until "Обсудить" clicked -->
      <div class="pb-chat" id="pb-chat" style="display:none">
        <div class="pb-chat-log" id="pb-chat-log"></div>
        <div class="pb-chat-row">
          <input class="pb-chat-input" id="pb-chat-input" type="text" placeholder="Спроси про эту страницу…" maxlength="300" />
          <button class="pb-chat-send" id="pb-chat-send" title="Отправить">→</button>
        </div>
        <button class="pb-l3 pb-l3--chat" id="pb-l3-chat">
          <span class="pb-thin">сделать в</span>&nbsp;<span class="pb-bold">Proji</span>
          <span class="pb-arr">&nbsp;→</span>
        </button>
      </div>
    </div>`;

  document.body.appendChild(el);
  BS.el = el;
  applyTheme();

  // Свернуть карточку в мини-виджет — переписка и рекомендация НЕ сбрасываются
  el.querySelector('#pb-collapse').addEventListener('click', e => {
    e.stopPropagation();
    trackEvent('dismiss', BS.lastAnalysis);
    el.querySelector('#pb-card').style.display = 'none';
    el.querySelector('#pb-mini').style.display = 'flex';
    el.querySelector('#pb-reopen').style.display = chatHistory.length ? 'flex' : 'none';
    el.classList.remove('pb--open');
  });

  // Разворачивает карточку обратно (с сохранённым обсуждением), не уходя на сайт
  el.querySelector('#pb-reopen').addEventListener('click', e => {
    e.preventDefault();
    e.stopPropagation();
    el.querySelector('#pb-mini').style.display = 'none';
    el.querySelector('#pb-card').style.display = 'flex';
    el.classList.add('pb--open');
    if (chatHistory.length) {
      el.querySelector('#pb-actions').style.display = 'none';
      el.querySelector('#pb-chat').style.display = 'flex';
      el.classList.add('pb--chat');
    }
  });

  el.querySelector('#pb-l3').addEventListener('click', () => {
    trackEvent('click', BS.lastAnalysis);
    if (BS.lastAnalysis) openProji(BS.lastAnalysis.action, BS.lastAnalysis, BS.lastCtx);
    else window.open('https://proji.kz', '_blank');
  });

  el.querySelector('#pb-l3-chat').addEventListener('click', () => {
    trackEvent('click', BS.lastAnalysis);
    if (BS.lastAnalysis) openProji(BS.lastAnalysis.action, BS.lastAnalysis, BS.lastCtx, chatHistory);
    else window.open('https://proji.kz', '_blank');
  });

  wireFeedback(el);

  el.querySelector('#pb-discuss').addEventListener('click', () => openChatPanel());
  el.querySelector('#pb-chat-send').addEventListener('click', () => sendChatMessage());
  el.querySelector('#pb-chat-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') sendChatMessage();
  });

  makeDraggable(el);
  restorePosition(el);
}

// ─── INLINE CHAT ("Обсудить") ───────────────────────────────────────────────
// Однонаправленно: открыли — остаёмся в режиме чата. Верхние кнопки
// (сделать в Proji / Обсудить) скрываются, т.к. дублируют функции чата;
// CTA "сделать в Proji" переезжает под поле ввода.

let chatHistory = [];
let chatBusy = false;

function openChatPanel() {
  const el = BS.el;
  if (!el) return;
  el.querySelector('#pb-actions').style.display = 'none';
  el.querySelector('#pb-chat').style.display = 'flex';
  el.classList.add('pb--chat');

  trackEvent('discuss_open', BS.lastAnalysis);
  if (!chatHistory.length) seedChat();
  setTimeout(() => el.querySelector('#pb-chat-input')?.focus(), 50);
}

function resetChat() {
  chatHistory = [];
  const el = BS.el;
  if (!el) return;
  el.querySelector('#pb-chat').style.display = 'none';
  el.querySelector('#pb-chat-log').innerHTML = '';
  el.querySelector('#pb-actions').style.display = 'flex';
  el.querySelector('#pb-reopen').style.display = 'none';
  el.classList.remove('pb--chat');
}

function seedChat() {
  const cta = BS.lastAnalysis?.title || BS.lastAnalysis?.cta || 'этой странице';
  appendChatBubble('assistant', `Привет! Я ассистент Proji. Спроси меня про «${cta}» — помогу понять, как лучше оформить это в проект, задачи или базу знаний.`);
}

function appendChatBubble(role, text) {
  const log = BS.el?.querySelector('#pb-chat-log');
  if (!log) return;
  const div = document.createElement('div');
  div.className = `pb-chat-msg pb-chat-msg--${role}`;
  div.textContent = role === 'assistant' ? cleanMarkdown(text) : text;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}

async function sendChatMessage() {
  if (chatBusy) return;
  const input = BS.el?.querySelector('#pb-chat-input');
  const text = input?.value?.trim();
  if (!text) return;
  input.value = '';

  appendChatBubble('user', text);
  chatHistory.push({ role: 'user', content: text });
  trackEvent('discuss_message', BS.lastAnalysis);

  chatBusy = true;
  const typingEl = appendChatBubble('assistant', '…');

  try {
    const res = await new Promise(resolve => {
      chrome.runtime.sendMessage({
        type: 'PROJI_DISCUSS',
        payload: { messages: chatHistory.slice(-8), ctx: BS.lastCtx, analysis: BS.lastAnalysis },
      }, r => resolve(r));
    });
    const reply = res?.reply || 'Не получилось ответить — попробуй ещё раз.';
    typingEl.textContent = cleanMarkdown(reply);
    chatHistory.push({ role: 'assistant', content: reply });
  } catch (_) {
    typingEl.textContent = 'Не получилось ответить — попробуй ещё раз.';
  } finally {
    chatBusy = false;
  }
}

// ─── DRAG TO REPOSITION ─────────────────────────────────────────────────────

function makeDraggable(el) {
  let dragging = false, moved = false, startX = 0, startY = 0, origRight = 0, origBottom = 0;

  el.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    dragging = true; moved = false;
    startX = e.clientX; startY = e.clientY;
    const rect = el.getBoundingClientRect();
    origRight = window.innerWidth - rect.right;
    origBottom = window.innerHeight - rect.bottom;
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  function onMove(e) {
    if (!dragging) return;
    const dx = e.clientX - startX, dy = e.clientY - startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
    if (moved) {
      el.style.right = Math.max(4, origRight - dx) + 'px';
      el.style.bottom = Math.max(4, origBottom - dy) + 'px';
    }
  }

  function onUp() {
    dragging = false;
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
    if (moved) {
      savePosition(el.style.right, el.style.bottom);
      el.addEventListener('click', suppressClick, { capture: true, once: true });
    }
  }

  function suppressClick(e) { e.preventDefault(); e.stopPropagation(); }
}

function savePosition(right, bottom) {
  try { chrome.storage.local.set({ pbPos: { right, bottom } }); } catch (_) {}
}

function restorePosition(el) {
  try {
    chrome.storage.local.get(['pbPos'], r => {
      if (r?.pbPos?.right && r?.pbPos?.bottom) {
        el.style.right = r.pbPos.right;
        el.style.bottom = r.pbPos.bottom;
      }
    });
  } catch (_) {}
}

function applyTheme() {
  const el = BS.el;
  if (!el) return;
  const t = detectTheme();
  el.style.setProperty('--pb-bg',    t.cardBg);
  el.style.setProperty('--pb-bdr',   t.border);
  el.style.setProperty('--pb-txt',   t.text);
  el.style.setProperty('--pb-muted', t.muted);
  el.style.setProperty('--pb-sh',    t.shadow);
  el.style.setProperty('--pb-r',     t.radius);
  el.setAttribute('data-dark', t.isDark ? '1' : '0');
}

function upgradeBubble(data, ctx) {
  const el = BS.el;
  if (!el || !data?.cta) return;

  el.querySelector('#pb-l1').textContent = data.cta || data.title || '';
  el.querySelector('#pb-l2').textContent = data.description || data.reason || '';
  el.querySelector('#pb-fb').innerHTML = `
    <span class="pb-fb-label">Точно?</span>
    <button class="pb-fb-btn" id="pb-fb-up" title="Да, в точку">👍</button>
    <button class="pb-fb-btn" id="pb-fb-down" title="Мимо">👎</button>`;
  wireFeedback(el);
  el.querySelector('#pb-mini').style.display = 'none';
  el.querySelector('#pb-card').style.display = 'flex';
  el.classList.add('pb--open');
  BS.lastAnalysis = data;
  BS.lastCtx = ctx;
  applyTheme();
  trackEvent('impression', data);
}

// ─── AUTO ANALYSIS ────────────────────────────────────────────────────────

async function runAnalysis(silent = true) {
  if (BS.analyzing) return;
  const ctx = extractContext();
  if (!ctx.text || ctx.text.length < 60) return;
  if (silent && ctx.text === BS.lastText) return;
  BS.lastText = ctx.text;
  BS.analyzing = true;
  try {
    const result = await callLLM({ ...ctx, envType: ENV });
    if (result?.cta || result?.title) upgradeBubble(result, ctx);
  } catch (_) {
    // Silent fail — static link stays
  } finally {
    BS.analyzing = false;
  }
}

function setupAutoAnalysis() {
  if (AI_SEL) {
    let prevLen = 0;
    new MutationObserver(() => {
      const len = [...document.querySelectorAll(AI_SEL)].reduce((s,n) => s+(n.textContent?.length||0), 0);
      if (len > prevLen + 80) {
        prevLen = len;
        clearTimeout(BS.timer);
        BS.timer = setTimeout(() => runAnalysis(true), 2500);
      }
    }).observe(document.body, { childList:true, subtree:true, characterData:true });
    setTimeout(() => runAnalysis(true), 2000);
  } else {
    setTimeout(() => runAnalysis(true), 3000);
  }
}

// ─── SPA / DYNAMIC-CONTENT WATCHER ──────────────────────────────────────────
// На SPA-сайтах (Gmail и т.п.) URL и контент меняются без перезагрузки
// страницы — content script переживает это, но без вотчера виджет
// показывал бы анализ ПЕРВОЙ открытой "страницы" вечно. Опрашиваем раз в
// 10с (т.е. отставание максимум ~10-20с) и обновляем при изменении.

function resetBubbleToStatic() {
  const el = BS.el;
  if (!el) return;
  resetChat(); // новая страница — старое обсуждение больше не релевантно
  el.querySelector('#pb-card').style.display = 'none';
  el.querySelector('#pb-mini').style.display = 'flex';
  el.classList.remove('pb--open');
  BS.lastAnalysis = null;
  BS.lastCtx = null;
  BS.lastText = '';
}

function setupContentWatcher() {
  let lastHref = location.href;
  let lastLen = document.body.innerText?.length || 0;

  setInterval(() => {
    const hrefChanged = location.href !== lastHref;
    const lenNow = document.body.innerText?.length || 0;
    const lenChanged = Math.abs(lenNow - lastLen) > 250;

    if (hrefChanged || lenChanged) {
      lastHref = location.href;
      lastLen = lenNow;
      resetBubbleToStatic();
      runAnalysis(false);
      if (hrefChanged) trackEvent('pageview', {});
    }
  }, 10000);
}

// ═══════════════════════════════════════════════════════════════════════════
//  SEARCH INJECTION
// ═══════════════════════════════════════════════════════════════════════════

function collectSearchSnippets() {
  const nodes = [...document.querySelectorAll(
    '#search .g, #rso > div, .serp-item, .OrganicTitle, #b_results .b_algo'
  )].slice(0, 5);
  return nodes
    .map(n => n.innerText?.replace(/\s{2,}/g, ' ').trim())
    .filter(t => t && t.length > 15)
    .map(t => t.slice(0, 180))
    .join('\n---\n');
}

async function injectSearchCard() {
  const q = new URLSearchParams(location.search).get('q') || new URLSearchParams(location.search).get('text') || '';
  if (!q) return;
  await new Promise(r => setTimeout(r, 1400));
  if (document.getElementById('proji-search-card')) return;

  const snippets = collectSearchSnippets();
  const ctxText = `Поисковый запрос: "${q}"${snippets ? `\n\nРезультаты выдачи:\n${snippets}` : ''}`;

  let data = null;
  try { data = await callLLM({ type:'search_query', platform:'search', text:ctxText, url:location.href }); } catch(_) {}

  const cta  = data?.cta  || 'Организуй это в Proji';
  const desc = data?.description || 'Превращай находки в задачи и проекты';
  const action = data?.action || 'task';

  const card = document.createElement('div');
  card.id = 'proji-search-card';
  card.className = 'proji-search-card';
  card.innerHTML = `
    <div class="psc-logo">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="6" fill="#4F6EF7"/><path d="M7 8h6a3 3 0 010 6H7V8z" fill="white"/><rect x="7" y="17" width="4" height="2" rx="1" fill="white"/></svg>
      <span class="psc-source">Proji</span>
      <span class="psc-tag">Инструмент</span>
    </div>
    <div class="psc-cta">${esc(cta)}</div>
    <div class="psc-desc">${esc(desc)}</div>
    <div class="psc-row">
      <button class="psc-btn"><span class="pb-thin">сделать в</span>&nbsp;<span class="pb-bold">Proji</span>&nbsp;→</button>
      <button class="psc-dismiss">✕</button>
    </div>`;

  card.querySelector('.psc-btn').addEventListener('click', () => openProji(action, {title:cta}, {text:q, url:location.href}));
  card.querySelector('.psc-dismiss').addEventListener('click', () => card.remove());

  const target = document.querySelector('#search .g:nth-child(3), #rso > div:nth-child(3), .serp-item:nth-child(3), #b_results .b_algo:nth-child(3)');
  if (target?.parentNode) target.parentNode.insertBefore(card, target.nextSibling);
  else document.querySelector('#search, #rso, .serp-list, #b_results')?.prepend(card);
}

// ═══════════════════════════════════════════════════════════════════════════
//  NEWS INJECTION
// ═══════════════════════════════════════════════════════════════════════════

const BANNER_SVG = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="110" viewBox="0 0 320 110"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#4F6EF7"/><stop offset="100%" stop-color="#7C3AED"/></linearGradient></defs><rect width="320" height="110" fill="url(#g)"/><rect x="16" y="18" width="68" height="74" rx="9" fill="rgba(255,255,255,0.12)"/><rect x="100" y="18" width="68" height="74" rx="9" fill="rgba(255,255,255,0.12)"/><rect x="184" y="18" width="68" height="74" rx="9" fill="rgba(255,255,255,0.12)"/><rect x="24" y="26" width="42" height="4" rx="2" fill="rgba(255,255,255,0.4)"/><rect x="108" y="26" width="42" height="4" rx="2" fill="rgba(255,255,255,0.4)"/><rect x="192" y="26" width="42" height="4" rx="2" fill="rgba(255,255,255,0.4)"/><rect x="24" y="37" width="52" height="14" rx="5" fill="rgba(255,255,255,0.2)"/><rect x="24" y="56" width="52" height="14" rx="5" fill="rgba(255,255,255,0.2)"/><rect x="108" y="37" width="52" height="14" rx="5" fill="rgba(255,255,255,0.28)"/><rect x="108" y="56" width="52" height="14" rx="5" fill="rgba(255,255,255,0.18)"/><rect x="192" y="37" width="52" height="14" rx="5" fill="rgba(255,255,255,0.36)"/><path d="M200 44l5 5 9-9" stroke="white" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/><rect x="192" y="56" width="52" height="14" rx="5" fill="rgba(255,255,255,0.2)"/><path d="M200 63l5 5 9-9" stroke="rgba(255,255,255,0.55)" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>')}`;

function extractArticleText() {
  const art = document.querySelector('article,.article-body,.article__body,.news-body,.post-content,.story-body') || document.querySelector('main') || document.body;
  return art.innerText?.replace(/\s{3,}/g, '\n').trim().slice(0, 2000) || '';
}

async function injectNewsBanner() {
  await new Promise(r => setTimeout(r, 1800));
  if (document.getElementById('proji-news-banner')) return;

  const articleText = extractArticleText();
  const ctxText = `Заголовок: "${document.title}"${articleText ? `\n\nТекст статьи:\n${articleText}` : ''}`;

  let data = null;
  try { data = await callLLM({ type:'news_page', platform:'news', text:ctxText, url:location.href }); } catch(_) {}

  const cta    = data?.cta  || 'Сохрани это в базу знаний';
  const desc   = data?.description || 'Важная информация не потеряется в Proji Studio — вся команда будет в курсе';
  const action = data?.action || 'knowledge';

  const banner = document.createElement('div');
  banner.id = 'proji-news-banner';
  banner.className = 'proji-news-banner';
  banner.innerHTML = `
    <img class="pnb-img" src="${BANNER_SVG}" alt="Proji"/>
    <div class="pnb-body">
      <div class="pnb-brand">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="5" fill="#4F6EF7"/><path d="M7 8h6a3 3 0 010 6H7V8z" fill="white"/></svg>
        <span>Proji</span>
      </div>
      <div class="pnb-cta">${esc(cta)}</div>
      <div class="pnb-desc">${esc(desc)}</div>
      <button class="pnb-btn"><span class="pb-thin">сделать в</span>&nbsp;<span class="pb-bold">Proji</span>&nbsp;→</button>
    </div>
    <button class="pnb-close">✕</button>`;

  banner.querySelector('.pnb-btn').addEventListener('click',  () => openProji(action, {title:cta}, {text:document.title, url:location.href}));
  banner.querySelector('.pnb-close').addEventListener('click', () => banner.remove());

  // Find ad slot or inject in article middle
  const adSels = ['ins.adsbygoogle','[class*="advertisement"]','[class*="advert"]','[id*="yandex_rtb"]','[class*="ad-banner"]','[data-ad-slot]'];
  let done = false;
  for (const sel of adSels) {
    const ad = document.querySelector(sel);
    if (ad && ad.offsetHeight > 40) {
      ad.style.display = 'none';
      ad.parentNode.insertBefore(banner, ad);
      done = true; break;
    }
  }
  if (!done) {
    const art = document.querySelector('article,.article-body,.article__body,.news-body,.post-content,.story-body');
    if (art) {
      const ps = art.querySelectorAll('p');
      const mid = Math.max(Math.floor(ps.length / 2), 2);
      if (ps[mid]) { ps[mid].parentNode.insertBefore(banner, ps[mid]); done = true; }
    }
  }
  if (!done) document.body.appendChild(banner);
}

// ─── CONTEXT MENU ─────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener(msg => { if (msg.type === 'CONTEXT_MENU_ANALYZE') runAnalysis(false); });

// ─── INIT ─────────────────────────────────────────────────────────────────

function init() {
  createBubble();         // shows static link immediately
  setupAutoAnalysis();    // tries LLM in background; upgrades if it works
  // setupContentWatcher() отключён: периодическая переоценка раз в 10с
  // дёргала виджет/сбрасывала открытую рекомендацию во время чтения —
  // мешало UX. Если понадобится возвращать на SPA-сайтах вроде Gmail,
  // включать стоит на explicit-событиях (клик по письму и т.п.), не по таймеру.

  if (ENV === 'search') injectSearchCard();
  if (ENV === 'news')   injectNewsBanner();

  trackEvent('pageview', {});
}

document.readyState === 'loading'
  ? document.addEventListener('DOMContentLoaded', init)
  : init();

})();
