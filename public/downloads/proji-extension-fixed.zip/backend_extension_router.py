"""
Proji Extension API Endpoint
Добавить в основной FastAPI приложение (routers/extension.py)

POST /api/v1/extension/capture
POST /api/v1/extension/analytics
"""

from fastapi import APIRouter, HTTPException, Header, Depends
from pydantic import BaseModel, validator
from typing import Optional, Literal
from datetime import datetime
import uuid

router = APIRouter(prefix="/api/v1/extension", tags=["extension"])


# ─── SCHEMAS ──────────────────────────────────────────────────────────────────

class ExtensionCapturePayload(BaseModel):
    action: str          # task | project | knowledge | idea | meeting
    title: str
    context: Optional[str] = ""
    platform: Optional[str] = "web"   # chatgpt | gemini | claude_ai | deepseek | web
    url: Optional[str] = ""
    timestamp: Optional[str] = None
    source: Optional[str] = "extension"

    @validator("action")
    def validate_action(cls, v):
        allowed = {"task", "project", "knowledge", "idea", "meeting", "decision", "research"}
        if v not in allowed:
            raise ValueError(f"action must be one of {allowed}")
        return v

    @validator("title")
    def clean_title(cls, v):
        return v.strip()[:120]

    @validator("context")
    def clean_context(cls, v):
        return (v or "").strip()[:2000]


class CaptureResponse(BaseModel):
    ok: bool
    id: str
    redirect_url: str
    message: str


# ─── ENDPOINT ─────────────────────────────────────────────────────────────────

@router.post("/capture", response_model=CaptureResponse)
async def capture_from_extension(
    payload: ExtensionCapturePayload,
    authorization: Optional[str] = Header(None),
    x_source: Optional[str] = Header(None),
):
    """
    Принимает контекст из Chrome Extension и создаёт сущность в Proji.
    
    Поддерживаемые действия:
    - task: создать задачу
    - project: создать проект  
    - knowledge: добавить в базу знаний
    - idea: сохранить идею
    - meeting: создать встречу
    """

    # TODO: Аутентификация через JWT/Bearer token
    # user = await authenticate_extension_token(authorization)

    capture_id = str(uuid.uuid4())

    try:
        if payload.action == "task":
            item_id = await create_task_from_extension(payload)
            redirect = f"/tasks/{item_id}"

        elif payload.action == "project":
            item_id = await create_project_from_extension(payload)
            redirect = f"/projects/{item_id}"

        elif payload.action in ("knowledge", "idea", "decision", "research"):
            item_id = await create_knowledge_from_extension(payload)
            redirect = f"/knowledge/{item_id}"

        elif payload.action == "meeting":
            item_id = await create_meeting_from_extension(payload)
            redirect = f"/meetings/{item_id}"

        else:
            item_id = capture_id
            redirect = "/quick-add"

        return CaptureResponse(
            ok=True,
            id=item_id,
            redirect_url=f"https://app.proji.kz{redirect}",
            message=f"Создано: {payload.title}",
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── BUSINESS LOGIC (адаптировать под вашу БД) ────────────────────────────────

async def create_task_from_extension(payload: ExtensionCapturePayload) -> str:
    """
    Создаёт задачу в Proji из контекста расширения.
    Адаптировать под вашу модель Task и репозиторий.
    """
    task_id = str(uuid.uuid4())

    # Пример вставки в вашу БД:
    # await db.execute(
    #     """
    #     INSERT INTO tasks (id, title, description, source, source_url, created_at)
    #     VALUES ($1, $2, $3, $4, $5, NOW())
    #     """,
    #     task_id,
    #     payload.title,
    #     f"[{payload.platform.upper()}] {payload.context}",
    #     payload.source,
    #     payload.url,
    # )

    print(f"[Extension] Task created: {payload.title} | from {payload.platform} | {payload.url}")
    return task_id


async def create_project_from_extension(payload: ExtensionCapturePayload) -> str:
    """Создаёт проект из контекста расширения."""
    project_id = str(uuid.uuid4())
    print(f"[Extension] Project created: {payload.title} | from {payload.platform}")
    return project_id


async def create_knowledge_from_extension(payload: ExtensionCapturePayload) -> str:
    """Добавляет запись в базу знаний / Proji Studio."""
    knowledge_id = str(uuid.uuid4())
    print(f"[Extension] Knowledge saved: {payload.title} | context: {payload.context[:50]}...")
    return knowledge_id


async def create_meeting_from_extension(payload: ExtensionCapturePayload) -> str:
    """Создаёт встречу."""
    meeting_id = str(uuid.uuid4())
    print(f"[Extension] Meeting created: {payload.title}")
    return meeting_id


# ─── ANALYTICS ──────────────────────────────────────────────────────────────
# Одно событие жизненного цикла виджета: показ, клик, закрытие, отзыв
# о качестве рекомендации, факт открытия новой "страницы" (в т.ч. SPA-навигация).

class ExtensionEvent(BaseModel):
    event: Literal["impression", "click", "dismiss", "feedback_up", "feedback_down", "pageview"]
    action: Optional[str] = ""        # task | project | knowledge | ...
    cta: Optional[str] = ""
    title: Optional[str] = ""
    envType: Optional[str] = ""       # ai | search | news | web
    platform: Optional[str] = "web"   # chatgpt | gemini | claude_ai | ... | web
    url: Optional[str] = ""
    hostname: Optional[str] = ""
    timestamp: Optional[str] = None


@router.post("/analytics")
async def track_extension_event(
    event: ExtensionEvent,
    authorization: Optional[str] = Header(None),
    x_source: Optional[str] = Header(None),
):
    """
    Принимает событие от расширения для аналитики/оценки качества рекомендаций.

    Хранить как минимум: event, action, cta, title, envType, platform,
    hostname, url, timestamp, (опционально user_id из authorization).

    На этих данных можно считать:
    - impression -> click конверсию (CTR) по hostname/envType/action
    - долю feedback_up / feedback_down — точность рекомендаций по теме/типу страницы
    - частоту pageview — на скольких страницах/доменах виджет вообще активировался
    - распределение по action (task/project/knowledge/...) — что чаще предлагается
    - распределение по envType/platform — где расширение полезнее всего
    """
    # TODO: записать в таблицу extension_events (БД), сджойнить с user по token
    print(f"[Extension][Analytics] {event.event} | {event.action} | {event.hostname} | {event.cta}")
    return {"ok": True}


# ─── РЕГИСТРАЦИЯ В MAIN APP ───────────────────────────────────────────────────
# В main.py добавить:
#
# from routers.extension import router as extension_router
# app.include_router(extension_router)
#
# Также добавить CORS для chrome-extension://*:
#
# from fastapi.middleware.cors import CORSMiddleware
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # или конкретный extension ID
#     allow_methods=["POST", "GET", "OPTIONS"],
#     allow_headers=["*"],
# )
