document.addEventListener('DOMContentLoaded', () => {
  const groqKey = document.getElementById('groq-key');
  const orKey = document.getElementById('or-key');
  const togOn = document.getElementById('tog-on');
  const slbl = document.getElementById('slbl');
  const toast = document.getElementById('toast');

  chrome.storage.sync.get(['groqKey','openrouterKey','enabled'], r => {
    if (r.groqKey) groqKey.value = r.groqKey;
    if (r.openrouterKey) orKey.value = r.openrouterKey;
    const on = r.enabled !== false;
    togOn.checked = on;
    slbl.textContent = on ? 'Активно' : 'Выключено';
  });

  document.getElementById('save-btn').addEventListener('click', () => {
    chrome.storage.sync.set({
      groqKey: groqKey.value.trim(),
      openrouterKey: orKey.value.trim(),
    }, () => showToast('Сохранено ✓'));
  });

  togOn.addEventListener('change', () => {
    const on = togOn.checked;
    chrome.storage.sync.set({ enabled: on });
    slbl.textContent = on ? 'Активно' : 'Выключено';
  });

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('toast--v');
    setTimeout(() => toast.classList.remove('toast--v'), 2000);
  }
});
