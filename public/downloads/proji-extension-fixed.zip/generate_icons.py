from PIL import Image, ImageDraw
import os

os.makedirs('/home/claude/proji-extension/icons', exist_ok=True)

def make_icon(size):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Rounded rect background
    r = int(size * 0.28)
    draw.rounded_rectangle([0, 0, size-1, size-1], radius=r, fill=(79, 110, 247, 255))
    
    # P shape (Proji logo)
    pad = int(size * 0.28)
    sw = int(size * 0.14)  # stroke width
    
    # Vertical bar
    draw.rectangle([pad, pad, pad + sw, size - pad], fill=(255, 255, 255, 255))
    
    # Horizontal top
    mid_y = int(size * 0.56)
    arc_r = (mid_y - pad) // 2
    cx = pad + sw
    cy = pad + arc_r
    
    # Arc / bump for P
    draw.ellipse([cx, pad, cx + arc_r*2, pad + arc_r*2], fill=(255, 255, 255, 255))
    # Fill inside to make it a C shape
    inner_pad = int(size * 0.05)
    draw.ellipse([cx + inner_pad, pad + inner_pad, cx + arc_r*2 - inner_pad, pad + arc_r*2 - inner_pad], 
                 fill=(79, 110, 247, 255))
    # Bottom part of P - connect
    draw.rectangle([pad, pad + arc_r, pad + sw, pad + arc_r*2], fill=(255, 255, 255, 255))
    
    return img

for size in [16, 48, 128]:
    icon = make_icon(size)
    icon.save(f'/home/claude/proji-extension/icons/icon{size}.png')
    print(f'Generated icon{size}.png')

print('Icons generated!')
